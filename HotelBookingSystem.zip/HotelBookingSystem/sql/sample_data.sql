INSERT INTO Rooms VALUES (101, 'Single', 50.0, FALSE);
INSERT INTO Rooms VALUES (102, 'Double', 80.0, FALSE);
INSERT INTO Customers (name, contact) VALUES ('John Doe', '1234567890');
